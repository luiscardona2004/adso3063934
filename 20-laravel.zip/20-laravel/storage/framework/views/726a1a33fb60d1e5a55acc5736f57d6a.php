<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>All Pets</title>
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ccc; padding: 6px; font-size: 12px; }
        th { background: #f4f4f4; }
    </style>
</head>
<body>
    <h2>All Pets</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Kind</th>
                <th>Breed</th>
                <th>Age</th>
                <th>Weight</th>
                <th>Location</th>
                <th>Description</th>
                <th>Active</th>
                <th>Status</th>
                <th>Image</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($pet->id); ?></td>
                <td><?php echo e($pet->name); ?></td>
                <td><?php echo e($pet->kind); ?></td>
                <td><?php echo e($pet->breed); ?></td>
                <td><?php echo e($pet->age); ?></td>
                <td><?php echo e($pet->weight); ?></td>
                <td><?php echo e($pet->location); ?></td>
                <td><?php echo e($pet->description); ?></td>
                <td><?php echo e($pet->active ? 'Active' : 'Inactive'); ?></td>
                <td><?php echo e($pet->status ? 'Available' : 'Adopted'); ?></td>
                <td><img src="<?php echo e(public_path('images/'.$pet->image)); ?>" width="50" height="50" /></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH C:\Users\luisf\adso3063934\20-laravel\resources\views/pets/excel.blade.php ENDPATH**/ ?>