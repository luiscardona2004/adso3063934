<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@5" rel="stylesheet" type="text/css" />
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>

<?php
    if (Auth::user()->role == 'Administrador') {
        $image = 'images/fondo_admin.png';
    } else {
        $image = 'images/fondo_visitante.png';
    }
?>

<body
    class="min-h-[100dvh] bg-[url(<?php echo e(asset($image)); ?>)] bg-cover bg-fixed w-full flex flex-col gap-4 items-center justify-center p-8">
    <?php echo $__env->make('layouts.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" referrerpolicy="no-referrer"></script>
    <?php echo $__env->yieldContent('js'); ?>
    

</body>

</html>
<?php /**PATH C:\Users\luisf\adso3063934\20-laravel\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>