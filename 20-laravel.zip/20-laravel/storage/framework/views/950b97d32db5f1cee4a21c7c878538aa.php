<?php $__env->startSection('title', 'reset your password: Larapets 🐶'); ?>
<?php $__env->startSection('content'); ?>
    <section class="bg-[#0007] text-white rounded-lg w-5/12 p-8 flex flex-col gap-3 items-center justify-center">
        <h1 class="flex gap-4 justify-center items-center text-4xl">
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="#fff" viewBox="0 0 256 256">
                <path
                    d="M80,48A16,16,0,1,1,64,32,16,16,0,0,1,80,48Zm48-16a16,16,0,1,0,16,16A16,16,0,0,0,128,32Zm64,32a16,16,0,1,0-16-16A16,16,0,0,0,192,64ZM64,88a16,16,0,1,0,16,16A16,16,0,0,0,64,88Zm64,0a16,16,0,1,0,16,16A16,16,0,0,0,128,88Zm64,0a16,16,0,1,0,16,16A16,16,0,0,0,192,88ZM64,144a16,16,0,1,0,16,16A16,16,0,0,0,64,144Zm64,0a16,16,0,1,0,16,16A16,16,0,0,0,128,144Zm0,56a16,16,0,1,0,16,16A16,16,0,0,0,128,200Zm64-56a16,16,0,1,0,16,16A16,16,0,0,0,192,144Z">
                </path>
            </svg>
            Forgot your password?
        </h1>
        <div class="divider divider-neutral p-[0] m-[0]"></div>

        <p>Forgot your password? No problem. Just let us know your email address and we will email you a password reset link
            that will allow you to choose a new one</p>
        <div class="card w-full max-w-sm ">
            <form method="POST" action="<?php echo e(route('password.store')); ?>" class="card-body ">
                
                <?php echo csrf_field(); ?>

                <input type="hidden" name="token" value="<?php echo e($request->route('token')); ?>">

                <label class="label ">Email</label>
                <input type="text" name="email" class="input bg-[#0006] w-full mt-1 outline-0" required
                    placeholder="Email" />
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="badge badge-outline badge-error w-full mt-1"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                
                <label class="label">Password</label>
                <input type="password" class="input bg-[#0006] w-full mt-1 outline-0" name="password"
                    placeholder="Password" />
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="badge badge-outline badge-error w-full mt-1 py-4.5"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                
                <label class="label">Confirm Password</label>
                <input type="password" class="input bg-[#0006] w-full outline-0" name="password_confirmation"
                    placeholder="Password" />


                <button class="btn btn-outline hover:bg-[#fff6] hover:text-white mt-4">Submit</button>

                <p class="text-sm text-center">

                    <a class="link link-default justify-center items-center" href="<?php echo e(route('login')); ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="#fff   "
                            viewBox="0 0 256 256">
                            <path
                                d="M232,200a8,8,0,0,1-16,0,88.1,88.1,0,0,0-88-88H51.31l34.35,34.34a8,8,0,0,1-11.32,11.32l-48-48a8,8,0,0,1,0-11.32l48-48A8,8,0,0,1,85.66,61.66L51.31,96H128A104.11,104.11,0,0,1,232,200Z">
                            </path>
                        </svg>
                    </a>
                </p>
            </form>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\luisf\adso3063934\20-laravel\resources\views/auth/reset-password.blade.php ENDPATH**/ ?>