<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return "<h1 style='text-align: center;
                        margin: 19rem auto; font-family:Arial'>
                        ✅ Check API Endpoints in Postman or apidog 🚀
                        </h1>";
});
